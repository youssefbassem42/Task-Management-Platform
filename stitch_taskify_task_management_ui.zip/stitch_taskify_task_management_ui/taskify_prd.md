# Taskify Product Requirements

## Global Design Instructions
- Modern, clean, minimal SaaS UI
- Soft shadows, rounded corners (12–20px), glassy light backgrounds
- Consistent 8px grid spacing
- Card-based layouts
- High readability and hierarchy

## Visual Identity
- **Colors:**
    - Primary: Blue gradient (#2563EB)
    - Secondary: Mint green (#58B879)
    - Accent: Orange
    - Status: To Do (Blue), In Progress (Orange), Review (Gray), Done (Green), Blocked (Dark Gray)
- **Typography:** Inter (Bold for headings, Regular for body)

## Component Specifications
- **Task Cards:** Avatars, tags, icons
- **Status Chips:** Rounded, colored labels
- **Avatars:** Hover tooltips with names
- **Buttons:** Primary (solid blue), Secondary (outlined), Icon buttons
- **Inputs:** Rounded, subtle borders, blue glow focus
- **Charts:** Clean bar/pie charts with minimal legends

## Screen Requirements
1. **Sign Up:** Centered card, logo, live password validation, social signup.
2. **Login:** Email/Password, Remember Me, social login.
3. **Verify Account:** Info screen with mail icon.
4. **Verification Success:** Success state, CTA to Login.
5. **Forgot Password:** Two-step flow (Email link -> New Password).
6. **Profile:** Editable name/image, password change section.
7. **Dashboard:** Grid-based cards with Task Summary, Priority Bar Chart, Distribution Pie Chart, and Priority Task List.
8. **Boards Page:** Grid of board cards with progress bars and member avatars.
9. **Mobile Adaptation:** Stacked layouts, bottom nav/drawer.
