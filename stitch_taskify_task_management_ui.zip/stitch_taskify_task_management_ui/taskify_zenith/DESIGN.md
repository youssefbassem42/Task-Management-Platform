# Design System Strategy: The Fluid Architect

## 1. Overview & Creative North Star
This design system is built upon the "Fluid Architect" philosophy. We are moving away from the rigid, boxed-in nature of traditional SaaS platforms and toward an editorial, high-end digital environment. The goal is to provide a sense of calm productivity through **Soft Minimalism**—an approach that prioritizes breathing room, organic depth, and intentional asymmetry.

To break the "template" look, we utilize a sophisticated layering system where content isn't just placed on a page; it is architected into a series of physical planes. By leveraging high-contrast typography scales and glassmorphism, we create an interface that feels both authoritative and weightless.

---

## 2. Color & Chromatic Soul
The palette is anchored by a deep, intelligent blue and a refreshing mint, balanced by the energetic spark of accent orange. 

### The "No-Line" Rule
To achieve a premium feel, **1px solid borders are strictly prohibited for sectioning.** Structural boundaries must be defined through tonal shifts or background color transitions. For example, a sidebar should be distinguished from the main canvas by moving from `surface` to `surface_container_low`, never by a divider line.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of materials. 
- **Base Layer:** `surface` (#f7f9fb)
- **Content Zones:** `surface_container_low` (#f2f4f6)
- **Interactive Cards:** `surface_container_lowest` (#ffffff)
- **Nested Elements:** Use `surface_container_high` (#e6e8ea) to denote "sunken" areas like search bars or code blocks.

### Signature Textures: Glass & Gradients
- **Primary CTAs:** Use a linear gradient from `primary_container` (#2563eb) to `primary` (#004ac6) at a 135° angle. This adds a "jewel-toned" depth that flat colors lack.
- **Overlays:** Modals and floating menus must use Glassmorphism. Apply `surface_variant` at 60% opacity with a `20px` backdrop-blur to allow underlying colors to bleed through subtly.

---

## 3. Typography: The Editorial Edge
We use **Inter** not as a standard sans-serif, but as a Swiss-style editorial face. 

- **The Power Gap:** Create high contrast between `display-lg` (56px) for hero moments and `label-sm` (11px) for metadata. 
- **Rhythm:** Use `headline-lg` (32px) for page titles with generous `2.5rem` bottom margins to allow the layout to "breathe."
- **Status Typography:** Labels for "To Do" or "Blocked" should utilize `label-md` in all-caps with `0.05em` letter spacing to provide a technical, structured feel against the fluid body copy.

---

## 4. Elevation & Depth
Hierarchy in this system is achieved through **Tonal Layering** rather than structural lines.

- **The Layering Principle:** Place a `surface_container_lowest` card on a `surface_container_low` background. This creates a natural "lift" without the clutter of shadows.
- **Ambient Shadows:** When an element must float (e.g., a dropdown or active task card), use a diffuse shadow: `0px 12px 32px rgba(25, 28, 30, 0.04)`. The shadow color must be a tinted version of `on_surface`, never pure black.
- **The "Ghost Border":** If accessibility requires a container boundary, use a "Ghost Border"—the `outline_variant` token at 15% opacity. It should be felt, not seen.

---

## 5. Component Architecture

### Buttons: The Tactile Command
- **Primary:** Rounded (`full` or `xl`), using the Primary Blue Gradient. On hover, increase the gradient saturation.
- **Secondary:** Outlined using the "Ghost Border" rule. The text color is `primary`.
- **States:** Focus states must utilize a `4px` outer glow using `primary` at 20% opacity.

### Inputs: The Focused Aperture
- **Styling:** Soft rounded corners (`md` - 12px). Use `surface_container_highest` for the background to create a "sunken" field.
- **Interaction:** On focus, the background shifts to `surface_container_lowest` (white) with a `primary` blue glow. This mimics a light turning on.

### Cards & Lists: The Modular Canvas
- **No Dividers:** Lists are separated by vertical whitespace (8px or 16px increments). 
- **Card Styling:** Use `xl` (24px) corner radius for main dashboard cards to emphasize the "Soft Minimalist" aesthetic.
- **The Progress Mint:** Use `secondary` (#58B879) for "Done" states and success indicators. It provides a natural, calming contrast to the authoritative blue.

### Task Chips
- **Status-Specific Tones:** 
    - *To Do:* `primary_fixed` background with `on_primary_fixed` text.
    - *In Progress:* `tertiary_fixed` background with `on_tertiary_fixed` text (Orange).
    - *Blocked:* `surface_dim` background with `on_surface_variant` text.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use asymmetrical margins. A wider left margin for titles creates an editorial "white space" that feels high-end.
- **Do** stack surfaces. An "In Progress" chip should live on a white card, which lives on a light gray section.
- **Do** use backdrop blurs for any element that sits "above" the main content.

### Don’t:
- **Don’t** use 1px solid black or dark gray borders. It breaks the fluid illusion.
- **Don’t** use "Drop Shadows" with high opacity. If the shadow is obvious, it's too heavy.
- **Don’t** crowd the interface. If a screen feels full, increase the spacing grid from `8px` to `16px` for that section.
- **Don’t** use pure black text. Use `on_surface` (#191c1e) to maintain a soft, premium legibility.